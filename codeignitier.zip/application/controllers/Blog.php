<?php
defined('BASEPATH') OR exit('No direct script access allowed');
 
class Blog extends CI_Controller {
	
	function __construct(){
		parent::__construct();
		$this->load->model('m_data');
				$this->load->helper('url');
	}
	public function post(){
		$key = $this->uri->segment(3);
		$d['data'] = $this->m_data->list_posting($key);
		
		$this->load->view('post', $d);
	} 
	public function index(){
		$this->load->view('saya');
	}

}
