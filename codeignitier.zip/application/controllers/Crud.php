<?php
class Crud extends CI_Controller{
 
	function __construct(){
		parent::__construct();		
		$this->load->model('m_data');
		$this->load->helper('url');
 
	}
 
	function tambah_aksi(){
		$nama = $this->input->post('nama');
		$email = $this->input->post('email');
		$sub_pesan = $this->input->post('sub_pesan');
		$pesan = $this->input->post('pesan');
 
		$data = array(
			'nama' => $nama,
			'sub_pesan' => $sub_pesan,
			'pesan' => $pesan,
			'mail' => $email
			);
		$this->m_data->input_data($data,'contact');
		redirect('http://localhost/codeignitier/?success#section8');
	}
 
}
?>