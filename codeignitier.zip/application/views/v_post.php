
<!DOCTYPE html>
<html>
<head>
  <title>Data Post</title>
  <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>asset/v_post/css/bootstrap.css">
  <link rel="shortcut icon" href="#">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.4.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="<?php echo base_url() ?>asset/v_post/css/froala_editor.css">
  <link rel="stylesheet" href="<?php echo base_url() ?>asset/v_post/css/froala_style.css">
  <link rel="stylesheet" href="<?php echo base_url() ?>asset/v_post/css/plugins/code_view.css">
  <link rel="stylesheet" href="<?php echo base_url() ?>asset/v_post/css/plugins/image_manager.css">
  <link rel="stylesheet" href="<?php echo base_url() ?>asset/v_post/css/plugins/image.css">
  <link rel="stylesheet" href="<?php echo base_url() ?>asset/v_post/css/plugins/table.css">
  <link rel="stylesheet" href="<?php echo base_url() ?>asset/v_post/css/plugins/video.css">
  <link rel="stylesheet" href="<?php echo base_url() ?>asset/v_post/css/cloudflare.css">
  

  <style>

    div#editor {
      width: 81%;
      margin: auto;
      text-align: left;
    }
  </style>
</head>
<body>

<nav class="navbar navbar-default">
  <div class="container-fluid">
   
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="#">Hexca Administrator</a>
    </div>

    
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li class="active"><a href="../?page=data-post">Data Blog<span class="sr-only">(current)</span></a></li>
        <li><a href="#">User</a></li>

      </ul>
      <form class="navbar-form navbar-left">
        <div class="form-group">
          <input type="text" class="form-control" placeholder="Search">
        </div>
        <button type="submit" class="btn btn-default">Submit</button>
      </form>
      <ul class="nav navbar-nav navbar-right">
       
        <li><img src="../images/s.jpg" width="42" style="margin-top: 5px" class="img-circle"></li>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">saya <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="#">Edit Profil</a></li>
            <li role="separator" class="divider"></li>
            <li><a href="../../engine/access.php?logout">Logout</a></li>
          </ul>
        </li>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>


<div class="container">
	 	<div style="margin-left: 20px">
	 	<div class="row">
	 	<div class="col-md-4">

		<form method="post" action="proses.php?update=" enctype="multipart/form-data">
		<div class="form-group">
			<label>Judul</label>
			<input type="text" class="form-control" value="" name="judul">
		</div>

		</div>
		</div>
		</div>
		<!-- editor -->
  <div id="editor">
    
      <textarea id='edit' name="isi" style="margin-top: 30px;" placeholder="Type some text">
      
      </textarea>

      <input type="submit" name="vb" value="Update" class="btn btn-primary">
    </form>
  </div>
		
	 	<div class="container">
	 	<div style="margin-left: 20px">
	 	<div class="row">
	 	<div class="col-md-4">
		<form method="post" action="proses.php" enctype="multipart/form-data">
		<div class="form-group">
			<label>Judul</label>
			<input type="text" class="form-control" name="judul">
		</div>
	
	    
		</div>

		</div>
		</div>
		</div>
		<!-- editor -->
  <div id="editor">
      <textarea id='edit' name="isi" style="margin-top: 30px;" placeholder="Type some text">
        <h1>Textarea</h1>
        <p>The editor can also be initialized on a textarea.</p>
      </textarea>
      	</br>
		<input type="submit" name="vb" value="submit" class="btn btn-primary">
		</form>
  </div>
		

<div class="container">
  <div class="row">
		<div class="col-md-8">
	        <h2>Navigasi</h2>
	        <p>
				Halaman khusus admin hexca <a href="">Experiment coding</a> and <a href="">Hexca Limited</a>
			</p>
	
			
			<br/><br/><br/><br/><br/>
		</div>
</div>
		
	</div>


  <script type="text/javascript" src="<?php echo base_url() ?>asset/v_post/js/cloudflare.js"></script>
  <script type="text/javascript" src="<?php echo base_url() ?>asset/v_post/js/cloudflare2.js"></script>
  <script type="text/javascript" src="<?php echo base_url() ?>asset/v_post/js/cloudflare3.js"></script>
  <script type="text/javascript" src="<?php echo base_url() ?>asset/v_post/js/froala_editor.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url() ?>asset/v_post/js/plugins/align.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url() ?>asset/v_post/js/plugins/code_beautifier.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url() ?>asset/v_post/js/plugins/code_view.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url() ?>asset/v_post/js/plugins/draggable.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url() ?>asset/v_post/js/plugins/image.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url() ?>asset/v_post/js/plugins/image_manager.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url() ?>asset/v_post/js/plugins/link.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url() ?>asset/v_post/js/plugins/lists.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url() ?>asset/v_post/js/plugins/paragraph_format.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url() ?>asset/v_post/js/plugins/paragraph_style.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url() ?>asset/v_post/js/plugins/table.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url() ?>asset/v_post/js/plugins/video.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url() ?>asset/v_post/js/plugins/url.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url() ?>asset/v_post/js/plugins/entities.min.js"></script>

  <script>
      $(function(){
        $('#edit')
          .on('froalaEditor.initialized', function (e, editor) {
            $('#edit').parents('form').on('submit', function () {
              console.log($('#edit').val());
              return false;
            })
          })
          .froalaEditor({enter: $.FroalaEditor.ENTER_P, placeholderText: null})
      });
  </script>

<footer class="footer">
      <div class="container">
        <p class="text-muted">Place sticky footer content here.</p>
      </div>
    </footer>
<!-- <script type="text/javascript" src="js/jquery.js"></script> -->
<script type="text/javascript" src="<?php echo base_url() ?>asset/v_post/js/bootstrap.js"></script>


</body>
</html>