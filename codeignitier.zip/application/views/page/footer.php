
		
		
		<footer class="footer">
			<div class="top">
				<div class="container">
					<div class="row">
						<div class="col-sm-4">
							<h4>Address</h4>
							<p>No. 30A, Terusan piranha street, Malang,<br />Indonesia.</p>
						</div> 
						<div class="col-sm-4">
							<h4>Connect</h4>
							<div class="social-icons">
								<a href="http://facebook.com/arnold.andreastandholic" class="social-icon"><i class="fa fa-facebook"></i></a>
								<a href="http://twitter.com/arnoldstar1" class="social-icon"><i class="fa fa-twitter"></i></a>
								<a href="#" class="social-icon"><i class="fa fa-google-plus"></i></a>
								<a href="#" class="social-icon"><i class="fa fa-behance"></i></a>
								<a href="#" class="social-icon"><i class="fa fa-dribbble"></i></a>
							</div> 
						</div>
						<div class="col-sm-4">
							<h4>Contact</h4>
							<p>Tel: +61 123-456-7890<br />Mail: mail@kurniawan.info</p>
						</div> 
					</div> 
				</div> 
			</div> 
			<div class="bottom">Copyright &copy; Kurniawan. All Rights Reserved.</div> 
		</footer> 
	
		<script src="<?php echo base_url() ?>asset/js/jquery-1.11.2.min.js"></script>
		<script src="<?php echo base_url() ?>asset/js/bootstrap.min.js"></script>
		<script src="<?php echo base_url() ?>asset/js/jquery.inview.min.js"></script>
		<script src="<?php echo base_url() ?>asset/js/smoothscroll.js"></script>
		<script src="<?php echo base_url() ?>asset/js/jquery.knob.min.js"></script>
		<script src="<?php echo base_url() ?>asset/js/owl.carousel.min.js"></script>
		<script src="<?php echo base_url() ?>asset/js/isotope.pkgd.min.js"></script>
		<script src="<?php echo base_url() ?>asset/js/imagesloaded.pkgd.min.js"></script>
		<script src="https://maps.googleapis.com/maps/api/js?v=3.exp"></script>
		<script src="<?php echo base_url() ?>asset/js/scripts.js"></script>
		

	</body>

</html>