<?php include 'page/header.php' ?>
		<div class="responsive-menu">
			<a href="#" class="responsive-menu-close">Close <i class="ion-android-close"></i></a>
			<nav class="responsive-nav"></nav> 
		</div> 

		
		<div class="section-nav">
			<nav class="section1">
				<a href="#section2" class="forward"><i class="md md-chevron-right"></i></a>
				<a href="#section1" class="backward"><i class="md md-chevron-left"></i></a>
			</nav>
		</div> 
		<div class="sections">
			<div class="sections-wrapper clearfix">

				<!-- Home -->
				<section id="section1" class="no-padding-bottom active" style="background:#ffffff !important;">
					<div class="container">
						<div class="row">
							<div class="col-sm-7 vertical-center padding-fix">
								<h1>Backend and Frontend Website Developer</h1>
								<p>Hello, I’m Kurniawan. I Have 4 years of experience in Web development. I am worked on a variety of brands and with agencies both big and small.</p>
								<p class="button-row"><a href="mailto:mail@kurniawan.info" class="button solid-button white">Hire Me Now</a><a href="<?php echo base_url() ?>asset/doc/kurniawan.pdf" class="button solid-button purple">Download CV</a></p>
							</div> 
							<!-- <div class="col-sm-5 vertical-center">
								<img src="<?php echo base_url() ?>asset/images/man01.png" alt="man" class="img-responsive img-bordered section-img">
							</div>  -->
							<div style="height: 300px">
								
							</div>
						</div> 
					</div> 
				</section> 

				<!-- Portfolio -->
				<section id="section2">
					<div class="container">
						<h2>Portfolio</h2>
						<div class="portfolio-wrapper">
							<div id="portfolio-filters" class="portfolio-filters">
								<button class="button solid-button white-purple small" data-filter="*">Show All</button>
								<button class="button solid-button white-purple small" data-filter=".branding">Shemura MT</button>
								<!-- <button class="button solid-button white-purple small" data-filter=".print">Print</button> -->
								<button class="button solid-button white-purple small" data-filter=".motion">Hexca</button>
							<!-- 	<button class="button solid-button white-purple small" data-filter=".websites">Websites</button> -->
							</div>
							<div id="portfolio" class="portfolio">
								<div class="item branding print">
									<img src="<?php echo base_url() ?>asset/images/portfolio01.jpg" alt="alt text" class="img-responsive">
									<a href="<?php echo base_url() ?>project/portfolio/1" class="overlay">
										<div class="background"></div>
										<div class="meta">
											<span class="title">Shemura MT - 01</span>
											<span class="category">Lock mode</span>
										</div> <!-- end .meta -->
									</a> <!-- end .overlay -->
								</div> <!-- end .item -->
								<div class="item branding print">
									<img src="<?php echo base_url() ?>asset/images/portfolio02.jpg" alt="alt text" class="img-responsive">
									<a href="<?php echo base_url() ?>project/portfolio/1" class="overlay">
										<div class="background"></div>
										<div class="meta">
											<span class="title">Shemura MT - 02</span>
											<span class="category">Home page</span>
										</div> <!-- end .meta -->
									</a> <!-- end .overlay -->
								</div> <!-- end .item -->
								<div class="item hidden print">
									<img src="<?php echo base_url() ?>asset/images/portfolio03.jpg" alt="alt text" class="img-responsive">
									<a href="<?php echo base_url() ?>project/portfolio/1" class="overlay">
										<div class="background"></div>
										<div class="meta">
											<span class="title">Portfolio Item - 03</span>
											<span class="category">Print</span>
										</div> <!-- end .meta -->
									</a> <!-- end .overlay -->
								</div> <!-- end .item -->
								<div class="item hidden print websites">
									<img src="<?php echo base_url() ?>asset/images/portfolio04.jpg" alt="alt text" class="img-responsive">
									<a href="<?php echo base_url() ?>project/portfolio/1" class="overlay">
										<div class="background"></div>
										<div class="meta">
											<span class="title">Portfolio Item - 04</span>
											<span class="category">Branding, Websites</span>
										</div> <!-- end .meta -->
									</a> <!-- end .overlay -->
								</div> <!-- end .item -->
								<div class="item print branding">
									<img src="<?php echo base_url() ?>asset/images/portfolio05.jpg" alt="alt text" class="img-responsive">
									<a href="<?php echo base_url() ?>project/portfolio/1" class="overlay">
										<div class="background"></div>
										<div class="meta">
											<span class="title">Portfolio Item - 05</span>
											<span class="category">Print, Branding</span>
										</div> <!-- end .meta -->
									</a> <!-- end .overlay -->
								</div> <!-- end .item -->
	<!-- 							<div class="item motion">
									<img src="<?php echo base_url() ?>asset/images/portfolio06.jpg" alt="alt text" class="img-responsive">
									<a href="<?php echo base_url('portfolio/1') ?>" class="overlay">
										<div class="background"></div>
										<div class="meta">
											<span class="title">Portfolio Item - 06</span>
											<span class="category">Motion</span>
										</div>
									</a>
								</div>  -->
					<!-- 			<div class="item motion">
									<img src="<?php echo base_url() ?>asset/images/portfolio07.jpg" alt="alt text" class="img-responsive">
									<a href="<?php echo base_url() ?>project/portfolio/1" class="overlay">
										<div class="background"></div>
										<div class="meta">
											<span class="title">Portfolio Item - 07</span>
											<span class="category">Motion</span>
										</div>
									</a> 
								</div>  -->
								<div class="item hidden print">
									<img src="<?php echo base_url() ?>asset/images/portfolio08.jpg" alt="alt text" class="img-responsive">
									<a href="<?php echo base_url() ?>project/portfolio/1" class="overlay">
										<div class="background"></div>
										<div class="meta">
											<span class="title">Portfolio Item - 08</span>
											<span class="category">Print</span>
										</div> <!-- end .meta -->
									</a> <!-- end .overlay -->
								</div> <!-- end .item -->
								<!-- <div class="item motion">
									<img src="<?php echo base_url() ?>asset/images/portfolio09.jpg" alt="alt text" class="img-responsive">
									<a href="<?php echo base_url() ?>project/portfolio/1" class="overlay">
										<div class="background"></div>
										<div class="meta">
											<span class="title">Portfolio Item - 09</span>
											<span class="category">Motion</span>
										</div> 
									</a> 
								</div>  -->
								<div class="item hidden websites">
									<img src="<?php echo base_url() ?>asset/images/portfolio10.jpg" alt="alt text" class="img-responsive">
									<a href="<?php echo base_url() ?>project/portfolio/1" class="overlay">
										<div class="background"></div>
										<div class="meta">
											<span class="title">Portfolio Item - 10</span>
											<span class="category">Websites</span>
										</div> <!-- end .meta -->
									</a> <!-- end .overlay -->
								</div> <!-- end .item -->
							</div> <!-- end .portfolio -->
							<div class="portfolio-load-more">
								<a href="<?php echo base_url() ?>project/portfolio/1" class="button solid-button white icon-right">Load More Work<i class="md-refresh"></i></a>
							</div> <!-- end .portfolio-load-more -->
						</div> <!-- end .portfolio-wrapper -->
					</div> <!-- end .container -->
				</section> <!-- end #section1 -->

				<!-- Blog -->
				<section id="section3">
					<div class="container">
						<h2>Blog Post</h2>
						<div class="blog-posts masonry" id="blog-masonry">
							<div class="blog-grid-sizer"></div>
							<div class="blog-post image-left">
								<div class="inner">
									<a href="<?php echo base_url().'blog/post/1' ?>"><div class="image" style="background-image: url('<?php echo base_url() ?>asset/images/portfolio01.jpg');"></div></a>
									<div class="content">
										<span class="date">March 14, 2015</span>
										<h4><a href="<?php echo base_url().'blog/post/1' ?>">E-commerce web application with Python technologies</a></h4>
										<footer>
											<span class="comments-link"><a href="<?php echo base_url().'blog/post/1' ?>">0 Comments</a></span>
											<span class="share-link"><a href="<?php echo base_url().'blog/post/1' ?>"><i class="fa fa-share-alt"></i></a></span>
										</footer>
									</div> <!-- end .content -->
								</div> <!-- end .inner -->
							</div> <!-- end .blog-post -->
							<div class="blog-post image-left">
								<div class="inner">
									<a href="<?php echo base_url().'blog/post/2' ?>"><div class="image" style="background-image: url('<?php echo base_url() ?>asset/images/codeigniter.jpg');"></div></a>
									<div class="content">
										<span class="date">March 9, 2016</span>
										<h4><a href="<?php echo base_url().'blog/post/2' ?>">Create view using Codeigniter</a></h4>
										<footer>
											<span class="comments-link"><a href="<?php echo base_url().'blog/post/2' ?>">0 Comments</a></span>
											<span class="share-link"><a href="<?php echo base_url().'blog/post/2' ?>"><i class="fa fa-share-alt"></i></a></span>
										</footer>
									</div> <!-- end .content -->
								</div> <!-- end .inner -->
							</div> <!-- end .blog-post -->
						</div> <!-- end .blog-posts -->
						<div class="blog-load-more">
							<a href="single-blog-post.html" class="button solid-button white icon-right">Load More Posts<i class="md-refresh"></i></a>
						</div> <!-- end .blog-load-more -->
					</div> <!-- end .container -->
				</section> <!-- end #section1 -->

				<!-- Contact -->
				<section id="section4">
					<div class="container">
						<h2>Get In Touch With Me</h2>
						<div class="row">
							<div class="col-sm-5">
								<h5>Contact Address</h5>
								<ul class="list-icons list-unstyled">
									<li><i class="ion-ios-location-outline"></i>No. 30A, Terusan piranha street, Malang <br/>Indonesia.</li>
									<li><i class="ion-iphone"></i>Phone: +61 012 345 6789</li>
									<li><i class="ion-ios-email-outline"></i>Email: <a href="mailto:mail@dkurniawan.my.id">mail@kurniawan.info</a></li>
									<li><i class="ion-ios-home-outline"></i>Website: <a href="#">www.kurniawan.info</a></li>
								</ul>
								<div class="spacer"></div>
								<div class="social-icons">
									<a href="#" class="social-icon"><i class="fa fa-facebook"></i></a>
									<a href="#" class="social-icon"><i class="fa fa-twitter"></i></a>
									<a href="#" class="social-icon"><i class="fa fa-google-plus"></i></a>
									<a href="#" class="social-icon"><i class="fa fa-behance"></i></a>
									<a href="#" class="social-icon"><i class="fa fa-dribbble"></i></a>
								</div> <!-- end .social-icons -->
								<div class="spacer"></div>
							</div>
							<div class="col-sm-7">
							
								<h5>Contact Form</h5>
								<form action="<?php echo base_url() ?>crud/tambah_aksi" method="post" class="form-horizontal">
									<div class="form-group">
										<label class="col-sm-2 control-label">Name</label>
										<div class="col-sm-10">
											<input type="text" class="contact-name" name="nama" />
										</div> 
									</div> 
									<div class="form-group">
										<label class="col-sm-2 control-label">Email</label>
										<div class="col-sm-10">
											<input type="email" class="contact-email" name="email" />
										</div> 
									</div> 
									<div class="form-group">
										<label class="col-sm-2 control-label">Subject</label>
										<div class="col-sm-10">
											<input type="text" class="contact-name" name="sub_pesan" />
										</div> 
									</div> 
									<div class="form-group">
										<label class="col-sm-2 control-label">Message</label>
										<div class="col-sm-10">
											<textarea name="pesan" class="contact-message" rows="3"></textarea>
										</div> 
									</div>
									<div class="form-group">
										<div class="col-sm-10 col-sm-offset-2">
											<button type="submit" class="button solid-button purple">Send Message</button>
										</div> 
									</div> 
									<div class="alert alert-success" role="alert"">
										<span>Success!</span>
										<button type="button" class="close" data-hide="alert" aria-label="Close"><i class="fa fa-times"></i></button>
									</div>
									<div class="contact-error alert alert-danger form-alert">
										<span class="message">Error!</span>
										<button type="button" class="close" data-hide="alert" aria-label="Close"><i class="fa fa-times"></i></button>
									</div>
								</form>
							</div>
						</div>
						<div class="map" id="map"></div>
					</div> 
				</section> 

			</div> 
		</div> 
<?php include 'page/footer.php' ?>