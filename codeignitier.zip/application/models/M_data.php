<?php
class M_data extends CI_Model{
	function tampil_data(){
		return $this->db->get('contact');
	}
function list_posting($key)
	{
        $query = $this->db->query("select * from blog where id = $key");
		$row = $query->row();
		return $row;
        }
	function input_data($data,$table){
		$this->db->insert($table,$data);
	}
}
?>